<?php

namespace App\Consts;

class AppVersion
{
    const VERSION= '3.1.6';
}